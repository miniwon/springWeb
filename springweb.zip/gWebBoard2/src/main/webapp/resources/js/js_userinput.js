$(function(){
	// 사용자의 자료 입력여부를 검사하는 함수
	$('#confirm').click(function(){
    	if( $.trim($("#userId").val()) == '' ){
            alert("아이디를 입력해 주세요.");
            $("#userId").focus();
            return;
        }
    	
    	if($.trim($('#userPass').val())==''){
    		alert("비번입력해주세요.");
    		$('#userPass').focus();
    		return;
    	}
    	
    	if($.trim($('#userPass').val()) != $.trim($('#userPass2').val())){
    		alert("비밀번호가 일치하지 않습니다..");
    		$('#userPass2').focus();
    		return;
    	}
    	
    	
    	if($.trim($('#userName').val())==''){
    		alert("이름입력해주세요.");
    		$('#userName').foucs();
    		return;
    	}
       
        // 자료를 전송합니다.
        document.userinput.submit();
	});
	
	//아이디 중복체크 -> 추후에는 [아이디 중복 화인] 버튼 클릭으로 변경
	$('#userId').keyup(function(){
        
        $.ajax({
        	url			: 'idCheck.do',
        	data		: { userId: $('#userId').val() },
        	// dataType	: 주로 'json/xml',
        	contentType	: 'application/x-www-form-urlencoded;charset=utf-8',
        	success		: checkId,
        	error		: function(err){
        	alert('error');
        	console.log(err);
        	}
        }); 
       function checkId(result){
       
       $('#idCheckResult').text(result);
       
       } // end of checkId
       
	}) // end of keyup
}) // end of $(function)